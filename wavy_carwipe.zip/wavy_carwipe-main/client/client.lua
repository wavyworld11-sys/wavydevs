local function EnumerateEntities(initFunc, moveFunc, disposeFunc)
    return coroutine.wrap(function()
        local iter, id = initFunc()
        if id == 0 then disposeFunc(iter) return end
        local enum = { handle = iter, destructor = disposeFunc }
        setmetatable(enum, { __gc = function(e)
            if e.destructor and e.handle then e.destructor(e.handle) end
            e.handle = nil
        end })
        local next = true
        repeat
            coroutine.yield(id)
            next, id = moveFunc(iter)
        until not next
        enum.destructor(iter)
    end)
end

local function EnumerateVehicles()
    return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
end

local function vehicleHasPlayers(vehicle)
    for seat = -1, GetVehicleMaxNumberOfPassengers(vehicle) do
        local ped = GetPedInVehicleSeat(vehicle, seat)
        if ped ~= 0 and IsPedAPlayer(ped) then
            return true
        end
    end
    return false
end

local function safeDeleteVehicle(vehicle)
    if not DoesEntityExist(vehicle) then return end

    NetworkRequestControlOfEntity(vehicle)
    local timeout = 500
    while timeout > 0 and not NetworkHasControlOfEntity(vehicle) do
        Wait(10)
        timeout = timeout - 10
    end

    if not NetworkHasControlOfEntity(vehicle) then return end

    SetEntityAsMissionEntity(vehicle, true, true)
    DeleteVehicle(vehicle)

    if DoesEntityExist(vehicle) then
        DeleteEntity(vehicle)
    end
end

-- Actual wipe execution
RegisterNetEvent('esx_carwipe:doWipe')
AddEventHandler('esx_carwipe:doWipe', function()
    local playerPed = PlayerPedId()
    local px, py, pz = table.unpack(GetEntityCoords(playerPed))

    for vehicle in EnumerateVehicles() do
        if DoesEntityExist(vehicle) and not vehicleHasPlayers(vehicle) then
            local vx, vy, vz = table.unpack(GetEntityCoords(vehicle))
            safeDeleteVehicle(vehicle)
            Wait(0)
        end
    end

    TriggerEvent('chat:addMessage', {
        color = {0, 0, 255}, -- BLUE
        args = {'CarWipe', "All inactive vehicles were wiped!"}
    })
end)

-- Countdown system
RegisterNetEvent('esx_carwipe:startCountdown')
AddEventHandler('esx_carwipe:startCountdown', function()
    CreateThread(function()
        local seconds = 30 -- fixed countdown

        -- First announcement + LOUD alert sound
        TriggerEvent('chat:addMessage', {
            color = {0, 0, 255}, -- BLUE
            args = {'CarWipe', ("Car wipe in %s seconds!"):format(seconds)}
        })
        for i = 1, 3 do
            PlaySoundFrontend(-1, "Event_Start_Text", "GTAO_FM_Events_Soundset", true)
            Wait(300)
        end

        -- Countdown every 5 seconds
        for i = seconds - 5, 5, -5 do
            Wait(5000)
            TriggerEvent('chat:addMessage', {
                color = {0, 0, 255},
                args = {'CarWipe', ("Car wipe in %s seconds!"):format(i)}
            })
        end

        -- Final wipe
        Wait(5000)
        TriggerEvent('chat:addMessage', {
            color = {0, 0, 255},
            args = {'CarWipe', "Wiping vehicles now!"}
        })
        for i = 1, 3 do
            PlaySoundFrontend(-1, "Event_Start_Text", "GTAO_FM_Events_Soundset", true)
            Wait(300)
        end

        TriggerEvent('esx_carwipe:doWipe')
    end)
end)
