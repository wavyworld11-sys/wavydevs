ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- CONFIG
local allowedGroups = { ['mod'] = true, ['admin'] = true, ['superadmin'] = true }

local function isAllowed(playerId)
    if playerId == 0 then return true end -- Console
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if not xPlayer then return false end
    return allowedGroups[xPlayer.getGroup()] == true
end

RegisterCommand('carwipe', function(source, args)
    if not isAllowed(source) then
        if source ~= 0 then
            TriggerClientEvent('chat:addMessage', source, {
                args = {'^1SYSTEM', 'You do not have permission to use this.'}
            })
        end
        return
    end

    -- Trigger anonymous countdown on all clients
    TriggerClientEvent('esx_carwipe:startCountdown', -1)

    -- Optional: print to server console (anonymous)
    print("[CarWipe] Wipe initiated.")
end, false)
