# Script by wavy

This resource is licensed under the **Wavy Proprietary License**.  
Do not redistribute without permission.

## Installation
1. Place this folder into your FiveM `resources` directory.
2. Add the resource name to your `server.cfg`:

```cfg
ensure my-resource-name
